/*
 * common_file.c
 *
 *  Created on: 03-Dec-2024
 *      Author: Admin
 */

#ifndef APPLICATION_COMMON_FILE_C_
#define APPLICATION_COMMON_FILE_C_


#include <stdint.h>

//Seconds_Time timeStamp;




#endif /* APPLICATION_COMMON_FILE_C_ */
